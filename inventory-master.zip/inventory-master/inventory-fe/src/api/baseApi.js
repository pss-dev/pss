function baseApi(url) {
  return `${url}`
}
export default{
  baseApi
}