const userInfo = {
  state: {
    userInfo
  },
  mutations: {},
  actions: {}
}

export default userInfo